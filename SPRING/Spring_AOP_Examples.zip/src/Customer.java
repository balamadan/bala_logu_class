
public interface Customer {
	public void browse() throws Exception;
}
