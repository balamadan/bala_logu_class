
public class College {
	private Student collegeStudent;
	
	public Student getCollegeStudent() {
		return collegeStudent;
	}


	public College(Student student){
		this.collegeStudent = student;
	}
}
